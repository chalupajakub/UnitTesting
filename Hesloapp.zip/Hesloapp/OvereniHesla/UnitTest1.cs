﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Hesloapp;

namespace OvereniHesla
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ObsahujeRPRPos()
        {
            HesloManager.NastavitHeslo("HesloRPRxxx");
            Assert.IsTrue(HesloManager.ObsahujeRPR());
        }

        [TestMethod]
        public void ObsahujeRPRNeg()
        {
            HesloManager.NastavitHeslo("Heslo123RPRxx");
            Assert.IsFalse(HesloManager.ObsahujeRPR());
        }

        [TestMethod]
        public void MaDelkuPos()
        {
            HesloManager.NastavitHeslo("heslo1234567");
            Assert.IsTrue(HesloManager.MaDelku());
        }

        [TestMethod]
        public void MaDelkuNeg()
        {
            HesloManager.NastavitHeslo("heslo1234567");
            Assert.IsFalse(HesloManager.MaDelku());
        }


        [TestMethod]
        public void JePrazdnePos()
        {
            HesloManager.NastavitHeslo("");
            Assert.IsTrue(HesloManager.JePrazdne());
        }


        [TestMethod]
        public void JePrazdneNeg()
        {
            HesloManager.NastavitHeslo("xxx");
            Assert.IsTrue(HesloManager.JePrazdne());
        }
    }
}
