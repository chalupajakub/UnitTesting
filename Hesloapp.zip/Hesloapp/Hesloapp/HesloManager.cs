﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hesloapp
{
    public static class HesloManager
    {
        public static string Heslo { get; set; }

        public static void NastavitHeslo(string heslo)
        {
            Heslo = heslo;
        }

        public static bool ObsahujeRPR()
        {
            return Heslo.Contains("RPR");
        }

        public static bool MaDelku()
        {
            return Heslo.Length >= 8 && Heslo.Length <= 20;
        }

        public static bool JePrazdne()
        {
            return Heslo == string.Empty;
        }
    }
}
